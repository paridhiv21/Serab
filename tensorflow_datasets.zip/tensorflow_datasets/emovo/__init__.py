"""emovo dataset."""

from tensorflow_datasets.emovo.emovo import Emovo
