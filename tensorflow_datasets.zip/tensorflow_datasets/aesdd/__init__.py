"""aesdd dataset."""

from tensorflow_datasets.aesdd.aesdd import Aesdd
