"""emoDB dataset."""

from tensorflow_datasets.emoDB.emoDB import Emodb
