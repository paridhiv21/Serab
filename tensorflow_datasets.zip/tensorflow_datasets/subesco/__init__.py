"""subesco dataset."""

from tensorflow_datasets.subesco.subesco import Subesco
