"""cafe dataset."""

from tensorflow_datasets.cafe.cafe import Cafe
