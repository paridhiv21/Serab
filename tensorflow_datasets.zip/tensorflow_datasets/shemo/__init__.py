"""shemo dataset."""

from tensorflow_datasets.shemo.shemo import Shemo
